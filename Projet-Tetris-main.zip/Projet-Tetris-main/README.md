# Projet Informatique Preing 1

Nous avons choisis le projet Tetris, les règles basiques de ce jeu que vous pouvez retrouver en cliquant sur ce lien https://fr.wikipedia.org/wiki/Tetris (vers wikipedia) sont appliquées.

Vous avez 5 secondes pour choisir la rotation ainsi que la colonne où vous voulez placer votre pièce. Passé ce temps, une colonne et une rotation seront choisies au hazard (ceci sera fait seulement après que vous ayez entré une colonne et une rotation hors temps).

Concernant le placement de la pièce, celle-ci se mettra dans la colonne choisie à partir de l'@ le plus bas à gauche.

Pour lancer le jeu, vous pouvez utiliser le makefile qui vous permettra de compiler et de créer l'executable (avec la commande make). Lorsque çe sera fait, si vous souhaitez supprimer les fichiers en .o créés, vous pouvez utiliser la commande make clear. Pour executer le programme, ouvrez un terminal et entrez la ligne de commande suivante : ./exec


BON JEU !

